import keras
from keras.models import Model
import cv2
import numpy as np
import time
import pandas as pd

from frame import frames_downsample, images_rescale
from opticalflow import OpticalFlow, frames2flows
from predict import get_predicts,i3d_LSTM_prediction


from multiprocessing import Process, Manager

from datagenerator import VideoClasses
from collections import OrderedDict

def calculate_oflow(rgbFrames, return_dict, indx, prev_f):
	#print(f"proess {indx} running got rgbFrames {rgbFrames.shape}")
	liFlows = []
	#if ind

	oOpticalFlow = OpticalFlow(sAlgorithm = "farnback", bThirdChannel = False, fBound = 20)
	
	if indx != 0:
		oOpticalFlow.arPrev = cv2.cvtColor(prev_f, cv2.COLOR_BGR2GRAY)#np.array(prev_f)
		#print(f"oOpticalFlow.arPrev shape {oOpticalFlow.arPrev.shape}")

	for i in range(len(rgbFrames)):
		arFlow = oOpticalFlow.next(rgbFrames[i])

		liFlows.append(arFlow)
		#print("in loop")


#	print(f"proess {i} got oflow = {liFlows.shape}")
	return_dict[indx] = np.array(liFlows)


def multiprocessing_oflow(rgbFrames, pro_num=4):
	# take normilized rgb Frames and return optical flow Frames
	# [TODO] multiprocessing
	rgbFrames = np.array(rgbFrames)
	#print(f"rgbFrame array is {rgbFrames.shape}")
	manager = Manager()
	return_dict = manager.dict()
	jobs = []
	l =int(len(rgbFrames)/pro_num)
	for i in range(pro_num):
		p = Process(target=calculate_oflow, 
					args=(rgbFrames[i*l:(i+1)*l,...],return_dict,i,rgbFrames[(i*l)-1,...])) 
		p.start()
		jobs.append(p)

	if len(rgbFrames) % pro_num != 0 :
		r = len(rgbFrames) % pro_num
		p = Process(target=calculate_oflow, 
					args=(rgbFrames[pro_num*l:(pro_num*l)+r, ...],return_dict,pro_num,rgbFrames[(pro_num*l)-1,...])) 
		p.start()
		jobs.append(p)

	#print("waiting...")
	for i in range(len(jobs)):
		jobs[i].join()

	#print("everthing is ok")

	od = OrderedDict(sorted(return_dict.items()))

	oflowFrames = []
	for k,v in od.items():
		#print(f" process {k} returned {v.shape}")
		oflowFrames.extend(v)

	return np.array(oflowFrames)

def vid2frames(vid, oflow):

	# Extract frames of a video and then normalize it to fixed-length 
	# Then make optical flow and RGB lists

	# Input : video(Stream), RGB(Boolean), oflow(Boolean)

	# Output : RGB-list, oflow-list

	rgbFrames,oflowFrames = None,None	
	
	tuRectangle = (224, 224)
	success, frame = vid.read()
	rgbFrames = []
	frame_num = 0

	while success:

		if not success:
			print("[warrning]: some video frames are corrupted.")

		# see if this line effecting the results
		frame = cv2.flip(frame, 1)
		frame = cv2.resize(frame, tuRectangle, interpolation =cv2.INTER_AREA)
		
		rgbFrames.append(frame)
		
		success, frame = vid.read()
		
		frame_num += 1	
	
	#rgbFrames = image_normalize(np.array(rgbFrames), 40)
	if len(rgbFrames) < 40:
		if oflow:
			oflowFrames = multiprocessing_oflow(rgbFrames, 2) #frames2flows(rgbFrames)
		rgbFrames = frames_downsample(np.array(rgbFrames), 40)
		oflowFrames = frames_downsample(oflowFrames, 40)
	else:
		rgbFrames = frames_downsample(np.array(rgbFrames), 40)
		if oflow:
			oflowFrames = multiprocessing_oflow(rgbFrames, 2) #frames2flows(rgbFrames)


	rgbFrames = images_rescale(rgbFrames)

	#print(rgbFrames.shape)
	#print(oflowFrames.shape)

	return rgbFrames, oflowFrames, frame_num


def handler(vid_dir, lstmModel, rgb_model, oflow_model, labels, pred_type, nTop):

	predictions = None

	vid = cv2.VideoCapture(vid_dir)

	print("Preprocessing data")
	preprocessing_time = time.time()
	rgbs,oflows,frame_num = vid2frames(vid,oflow_model is not None)
	print(f"preprocessing data took {round(time.time()-preprocessing_time,2)} sec") 

	print("running a prediction process ...")
	predictions_time = time.time()
	if pred_type == "word":
		if not lstmModel is None:
			predictions = i3d_LSTM_prediction(rgbs, oflows, labels, lstmModel, rgb_model, oflow_model, nTop)
		else:
			predictions = get_predicts(rgbs, oflows, labels, oflow_model, rgb_model, nTop)
	elif pred_type == "sentence":
		sent_preds(rgbs,oflows,frame_num,labels,lstmModel,rgb_model,oflow_model,
			nTop,frames_to_process=30,stride=10,threshold=40)
	else:
		raise ValueError("ERROR : unkown pred_type flag.")
	print(f"prediction took {round(time.time()-predictions_time,2)} sec")

	return predictions
	

def load_model_without_topLayer(model_path, last_desire_layer="global_avg_pool"):
    
    base_model = keras.models.load_model(model_path)

    model_no_top = Model(inputs=base_model.input, outputs=base_model.get_layer(last_desire_layer).output)

    return model_no_top

def dropped_cudnn_model(model):
	# not working properly 
	# [TODO] fix the code or make a model for cpu 
	before_layer = None
	i = 0
	for i in range(len(model.layers)):
		if 'lstm' in model.layers[i].name.lower():
			break
		before_layer = model.layers[i]
	before_model = Model(inputs=model.input, outputs=model.get_layer(before_layer.name).output)

	lstm_layer = model.layers[i]

	if 'bidirectional' in lstm.name.lower():
		from keras.layers import Bidirectional as lstm
	else:
		from keras.layers import LSTM as lstm

	lstm_output = lstm(lstm_layer.output,recurrent_activation='sigmoid',name="LSTM_1b")(before_model.ouput)

	i += 1
	for i in range(len(model.layers)):
		last_layer = model.layers[i]

	final_model = Model(inputs=model.input, outputs=model.get_layer(last_layer.name).output)

	return final_model

def load_models(models_dir,
				on_cpu,
				use_rgb,
				use_oflow,
				use_lstm):
	
	models = {'lstm' : None,'rgb': None,'oflow': None}

	def check(model):
		if models_dir[model] is None:
			raise ValueError(f"use_{model} flag is on and models_dir dict has no {model} key")

		print(f"uploading {model} ...")

	if use_rgb:
		check('rgb')
		models['rgb'] = keras.models.load_model(models_dir["rgb"])
	elif use_oflow:
		check('oflow')
		models['oflow'] = keras.models.load_model(models_dir["oflow"])
	elif use_lstm:
		check('rgb')
		models['rgb'] = load_model_without_topLayer(models_dir["rgb"])
		check('oflow')
		models['oflow'] = load_model_without_topLayer(models_dir["oflow"])
		check('lstm')
		if use_cpu:
			models['lstm'] = keras.model.load_model(models_dir['cpu'])
		else:
			models['lstm'] = keras.model.load_model(models_dir['lstm'])

	else:
		check('rgb')
		models['rgb'] = keras.models.load_model(models_dir["rgb"])
		check('oflow')
		models['oflow'] = keras.models.load_model(models_dir["oflow"])
		
	return models

"""
	if i3d_models["oflow"] is not None:
		if use_Edited_Model:
			oflow_model = load_model_without_topLayer(i3d_models["oflow"])
		else:

	if use_Edited_Model:
		lstmModel = keras.models.load_model(LSTM_model)

	return rgb_model,oflow_model,lstmModel
"""

def csv_to_dict(labels_dir,sWord_col):
    df = pd.read_csv(labels_dir)
    return dict(enumerate(df[sWord_col].tolist()))
